package cs2340.gatech.edu.lab3.model;

/**
 * Enum Class for ClassStanding
 */
public enum ClassStanding {
    FR, SO, JR, SR;
}
